<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyAgU5ZzsMR7FF0abXp761JtO_bx-YtdMQY",
    authDomain: "noname07new-dab1b.firebaseapp.com",
    databaseURL: "https://noname07new-dab1b.firebaseio.com"
    projectId: "noname07new-dab1b",
    storageBucket: "noname07new-dab1b.firebasestorage.app",
    messagingSenderId: "87853692032",
    appId: "1:87853692032:web:fa9266e3ba6c1daf50a265",
    measurementId: "G-TPG51TSEFC"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
</script>
